# Memory Game Project

## Table of Contents

* [Instructions](#instructions)
* [Contributing](#contributing)

## Instructions

Udacity memory game
## Contributing

The udacity memory game is started, everytime the player clicks on any of the faced-down cards. To win,
one would need to find all 8 matched pairs. Player's performance will be rated as stars. The game play duration will also be displayed onUdacity memory game

Libraries/additional dependencies:
 - Jquery
 - Sweetalert 
For details, check out [CONTRIBUTING.md](CONTRIBUTING.md).
