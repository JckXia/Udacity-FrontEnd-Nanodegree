frontend-nanodegree-arcade-game
===============================


The classic arcade game project is implemented in Object oriented javascript, alongside with Canvas HTML engine

#Start playing
To start playing the game, one will need to clone this repository and load the index.html file into browser

#Instruction:
Player must reach the water whilst avoid collision with the bugs
To move up: up arrow
To move down: down arrow
To move left: left arrow
To move right: right arrow
